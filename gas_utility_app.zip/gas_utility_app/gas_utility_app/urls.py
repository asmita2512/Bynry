"""
URL configuration for gas_utility_app project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# gas_utility_app/urls.py

from django.contrib import admin
from django.urls import path
from consumer_services import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('home/', views.home_view),
    path('consumer_service/', views.service_request_view),
    path('tracking/', views.tracking_view, name='request_tracking'),
    path('account/', views.account_info_view, name='Account_Info'),
    path('support/', views.support_view, name='Support'),
    # Add other URLs as needed
]
