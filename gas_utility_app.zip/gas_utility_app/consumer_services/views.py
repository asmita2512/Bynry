# consumer_services/views.py

from django.shortcuts import render, redirect
from .forms import ServiceRequestForm
from .models import ServiceRequest
from django.contrib.auth.decorators import login_required

def home_view(request):
    return render(request, 'consumer_services/index.html')

def service_request_view(request):
    if request.method == 'POST':
        form = ServiceRequestForm(request.POST, request.FILES)
        if form.is_valid():
            service_request = form.save(commit=False)
            service_request.customer = request.user
            service_request.save()
            return redirect('request_tracking')
    else:
        form = ServiceRequestForm()
    return render(request, 'consumer_services/service_request.html', {'form': form})

def tracking_view(request):
    service_requests = ServiceRequest.objects.filter(customer=request.user)
    return render(request, 'consumer_services/tracking.html', {'service_requests': service_requests})

@login_required
def account_info_view(request):
    # Fetch and pass customer account information to the template
    return render(request, 'consumer_services/account.html')

def support_view(request):
    # Fetch and pass service requests to the template for support representatives
    service_requests = ServiceRequest.objects.all()
    return render(request, 'consumer_services/support.html', {'service_requests': service_requests})

